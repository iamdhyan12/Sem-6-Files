<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 5-1:  array_fill() Function <br>";
$a1=array_fill(3,4,"blue");
$b1=array_fill(0,1,"red");
print_r($a1);
echo "<br>";
print_r($b1);
echo "<br>";

echo "Output:";
$b1=array_fill(2,2,"red");
print_r($b1);
?>

</body>
</html>