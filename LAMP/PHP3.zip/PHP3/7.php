<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 7-1:  <br>";
$a1=array("red","green");
$a2=array("blue","yellow");
print_r(array_replace($a1,$a2));

echo "<br> Example 7-2:  <br>";
$a1=array("a"=>"red","b"=>"green");
$a2=array("a"=>"orange","burgundy");
print_r(array_replace($a1,$a2));

echo "<br> Example 7-3:  <br>";
$a1=array("a"=>"red","green");
$a2=array("a"=>"orange","b"=>"burgundy");
print_r(array_replace($a1,$a2));

echo "<br> Example 7-4:  <br>";
$a1=array("red","green");
$a2=array("blue","yellow");
$a3=array("orange","burgundy");
print_r(array_replace($a1,$a2,$a3));

echo "<br> Example 7-5:  <br>";
$a1=array("red","green","blue","yellow");
$a2=array("0"=>"orange",3=>"burgundy");
print_r(array_replace($a1,$a2));
?>

</body>
</html>