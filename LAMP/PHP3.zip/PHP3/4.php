<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 4-0:  array_diff() Function <br>";
$a1=array(10,11,12,13,14,15);
$a2=array(10,12,20);
$a3=array(13,15);

$result=array_diff($a1,$a2,$a3);
print_r($result);

echo "<br>Example 4-1:  array_diff() Function <br>";
$a1=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");
$a2=array("e"=>"red","f"=>"black","g"=>"purple");
$a3=array("a"=>"red","b"=>"black","h"=>"yellow");
$result=array_diff($a1,$a2,$a3);
print_r($result);

echo "<br><br> Example 4-2:  array_diff_assoc() Function<br>";
$a1=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");
$a2=array("e"=>"red","f"=>"green","g"=>"blue");

$result=array_diff_assoc($a1,$a2);
print_r($result);

echo "<br><br> Example 4-3:  array_diff_assoc() Function<br>";
$a1=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");
$a2=array("a"=>"red","f"=>"green","g"=>"blue");
$a3=array("h"=>"red","b"=>"green","g"=>"blue");
$result=array_diff_assoc($a1,$a2,$a3);
print_r($result);

echo "<br><br> Example 4-4:  array_diff_key() Function<br>";
$a1=array("red","green","yellow","blue");
$a2=array("red","green","blue");
$result=array_diff_key($a1,$a2);
print_r($result);

echo "<br><br> Example 4-5:  array_diff_key() Function<br>";
$a1=array("a"=>"red","b"=>"green","c"=>"blue");
$a2=array("c"=>"yellow","d"=>"black","e"=>"brown");
$a3=array("f"=>"green","c"=>"purple","g"=>"red");

$result=array_diff_key($a1,$a2,$a3);
print_r($result);

?>

</body>
</html>