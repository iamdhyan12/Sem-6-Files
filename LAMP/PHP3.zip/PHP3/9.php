<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 9-1:  <br>";
$a=array(5,5);
echo(array_product($a));

echo "<br> Example 9-2:  <br>";
$a=array(5,5,2,10);
echo(array_product($a));

echo "<br> Example 9-3:  <br>";
$a=array("a"=>"Volvo","b"=>"BMW","c"=>"Toyota");
print_r(array_reverse($a));

echo "<br> Example 9-4:  <br>";
$a=array("Volvo","XC90",array("BMW","Toyota"));
$reverse=array_reverse($a);
$preserve=array_reverse($a,true);

print_r($a);
echo "<br>";
print_r($reverse);
echo "<br>";
print_r($preserve);

?>

</body>
</html>