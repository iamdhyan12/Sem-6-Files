<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 1-1.1: Push Operation <br>";
$a=array("red","green");
echo "length: ". array_push($a,"blue","yellow"). "<br/>" ;
print_r($a);

echo "Example 1-1.2: Push Operation <br>";
$a=array("key1"=>"red","key2"=>"green");
echo "length: ". array_push($a,"blue","yellow"). "<br/>" ;
print_r($a);

echo "<br> <br>Example 1-2: Pop Operation <br>";
$a=array("red","green","blue");
echo "POP element: ". array_pop($a). "<br/>" ;
print_r($a);

echo "<br> <br>Example 1-3: Shift Opeartion <br>";
$a=array("a"=>"red","b"=>"green","c"=>"blue");
//$a=array("red","green","blue");
//$a1=array();
echo "Shift operation returns: ".
array_shift($a)."<br>";
print_r ($a);

echo "<br> <br>Example 1-4: Shift Opeartion <br>";
$a=array(0=>"red",1=>"green",2=>"blue");
echo array_shift($a)."<br>";
print_r ($a);

echo "<br> <br>Example 1-5: Unshift Operation <br>";
$a=array("a"=>"red","b"=>"green");
print_r(array_unshift($a,"blue","yellow"));
echo "<br>";
print_r($a);	

echo "<br> <br>Example 1-6: Unshift Operation <br>";
$a=array("0"=>"red","1"=>"green");
array_unshift($a,"blue");
print_r($a);

?>

</body>
</html>