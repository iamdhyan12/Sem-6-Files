<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 6-1:  <br>";
$a1=array("red","green");
$a2=array("blue","yellow","green");
print_r(array_merge($a1,$a2));

echo "<br> Example 6-2:  <br>";
$a1=array("a"=>"red","b"=>"green");
$a2=array("c"=>"blue","b"=>"yellow");
print_r(array_merge($a1,$a2));

echo "<br> Example 6-3:  <br>";
$a=array(3=>"red",4=>"green");
$a1=array_merge($a);
print_r($a);


echo "<br> Example 6-4:  <br>";
$a1=array("red","green");
$a2=array("blue","yellow");
print_r(array_merge_recursive($a1,$a2));

echo "<br> Example 6-5:  <br>";
$a=array(3=>"red",4=>"green");
print_r(array_merge_recursive($a));

echo "<br> Example 6-6:  <br>";
$a1=array("a"=>"red","b"=>"green");
$a2=array("c"=>"blue","b"=>"yellow");
print_r(array_merge_recursive($a1,$a2));


?>

</body>
</html>