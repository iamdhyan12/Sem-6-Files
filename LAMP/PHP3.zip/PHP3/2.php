<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 2-1:  <br>";
// An array that represents a possible record set returned from a database
$a = array(
  array(   
    'first_name' => 'Peter',
    'last_name' => 'Griffin',
	 'id' => 5698
  ),
  array(
    'id' => 4767,
    'first_name' => 'Ben',
    'last_name' => 'Smith',
  ),
  array(
    'id' => 3809,
    'first_name' => 'Joe',
    'last_name' => 'Doe',
  )
);

$first_names = array_column($a, 'first_name');
print_r($first_names);
echo "<br>";
$last_names = array_column($a, 'last_name', 'id');
print_r($last_names);



?>

</body>
</html>