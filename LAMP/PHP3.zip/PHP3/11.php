<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 11-1:  <br>";
$a=array("red","green","blue","yellow","brown");
print_r(array_slice($a,2));

echo "<br> Example 11-2:  <br>";
$a=array("red","green","blue","yellow","brown");
print_r(array_slice($a,1,2));

echo "<br> Example 11-3:  <br>";
$a=array("red","green","blue","yellow","brown");
print_r(array_slice($a,-2,1));

echo "<br> Example 11-4:  <br>";
// Preserve parameter set to true:
$a=array("red","green","blue","yellow","brown");
print_r(array_slice($a,1,2,true));
echo "<br>";
// Preserve parameter set to false (default):
$a=array("red","green","blue","yellow","brown");
print_r(array_slice($a,1,2,false));

// Note the differences in the array keys

echo "<br> Example 11-5:  <br>";
$a=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow","e"=>"brown");
print_r(array_slice($a,1,2,false));
echo "<br>";
$a=array("0"=>"red","1"=>"green","2"=>"blue","3"=>"yellow","4"=>"brown");
print_r(array_slice($a,-5,-3));

echo "<br> Example 11-6:  <br>";
$a=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow","e"=>"brown");
print_r(array_slice($a,-4,-2,false));
?>

</body>
</html>