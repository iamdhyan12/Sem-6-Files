<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 8-1:  <br>";
$a1=array("a"=>array("red"),"b"=>array("green","blue"),);
$a2=array("a"=>array("yellow"),"b"=>array("black"));
print_r(array_replace_recursive($a1,$a2));

echo "<br> Example 8-2:  <br>";
$a1=array("a"=>array("red"),"b"=>array("green","blue"));
$a2=array("a"=>array("yellow"),"b"=>array("black"));
$a3=array("a"=>array("orange"),"b"=>array("burgundy"));
print_r(array_replace_recursive($a1,$a2,$a3));

echo "<br> Example 8-3:  <br>";
$a1=array("a"=>array("red"),"b"=>array("green","blue"),);
$a2=array("a"=>array("yellow"),"b"=>array("black"));
$result=array_replace_recursive($a1,$a2);
print_r($result);

$result=array_replace($a1,$a2);
print_r($result);


?>

</body>
</html>