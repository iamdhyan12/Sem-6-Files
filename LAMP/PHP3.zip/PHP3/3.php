<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 3-1: array_combine() Function <br>";
$fname=array("Peter","Ben","Joe");
$age=array("35","37","43");
$c=array_combine($fname,$age);
print_r($c);


echo "<br> Example 3-2:  array_count_values() Function<br>";
$a=array("Nirma","Uni","CE Dept","Nirma","Uni","CE ");
print_r(array_count_values($a));


?>

</body>
</html>