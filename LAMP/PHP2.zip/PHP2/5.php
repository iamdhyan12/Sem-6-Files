<!DOCTYPE html>
<html>
<body>

<?php

echo "Example 5-1:  <br>";
echo strcmp("Hello world!","Hello world!");

echo "<br><br>Example 5-2:  <br>";
echo strcmp("Hello","Hello");
echo "<br>";
echo strcmp("Hello","hELLo");

echo "<br><br>Example 5-3:  <br>";
echo strcmp("Hello world!","Hello world!")."<br>"; // the two strings are equal
echo strcmp("Hello world!","Hello")."<br>"; // string1 is greater than string2
echo strcmp("Hello world!","Hello world! Hello!")."<br>"; // string1 is less than string2

echo "Example 5-4:  <br>";
echo strchr("Hello world!","world");

echo "<br><br>Example 5-5:  <br>";
echo strchr("Hello world!",111);

echo "<br><br>Example 5-6:  <br>";
echo strchr("Hello world!","world",true);



?>

</body>
</html>