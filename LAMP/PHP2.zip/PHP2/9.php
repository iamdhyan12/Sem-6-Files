<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 9-1:  <br>";
echo substr_count("Hello world. The world is nice","world");

echo "<br>Example 9-2:  <br>";
$str = "This is nice";
echo strlen($str)."<br>"; // Using strlen() to return the string length
echo substr_count($str,"is")."<br>"; // The number of times "is" occurs in the string
echo substr_count($str,"is",2)."<br>"; // The string is now reduced to "is is nice"
echo substr_count($str,"is",3)."<br>"; // The string is now reduced to "s is nice"
echo substr_count($str,"is",3,3)."<br>"; // The string is now reduced to "s i"

echo "<br><br> Example 9-3:  <br>";
$str = "abcabcab"; 
echo substr_count($str,"abcab"); // This function does not count overlapped substrings, and will therefore only print 1

echo "<br><br> Example 9-4:  <br>";
echo $str = "This is nice";
echo "<br>".substr_count($str,"is",3,9);

?>

</body>
</html>