<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 4-1:  <br>";
print_r(str_split("Hello"));

echo "<br><br>Example 4-2:  <br>";
print_r(str_split("Hello",3));

echo "<br><br>Example 4-3:  <br>";
echo strcasecmp("Hello world!","HELLO WORLD!");

echo "<br><br>Example 4-4:  <br>";
echo strcasecmp("Hello","HELLO");
echo "<br>";
echo strcasecmp("Hello","hELLo");

echo "<br><br>Example 4-5:  <br>";
echo strcasecmp("Hello world!","HELLO WORLD!")."<br>"; // The two strings are equal
echo strcasecmp("Hello world!","HELLO")."<br>"; // String1 is greater than string2
echo strcasecmp("Hello world!","HELLO WORLD! HELLO!")."<br>"; // String1 is less than string2 
?>

</body>
</html>