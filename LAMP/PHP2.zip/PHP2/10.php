<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 10-1:  <br>";
echo substr_replace("Hello","world",0); // 0 will start replacing at the first character in the string

echo "<br>Example 10-2:  <br>";
echo substr_replace("Hello world","earth",6);

echo "<br><br> Example 10-3:  <br>";
echo substr_replace("Hello world","earth",-5);

echo "<br><br> Example 10-4:  <br>";
echo substr_replace("world","Hello ",0,0);

echo "<br><br> Example 10-5:  <br>";
$replace = array("1: AAA","2: AAA","3: AAA");

// Replace AAA in each string with BBB
echo implode("<br>",substr_replace($replace,'BBB',3,3));
?>

</body>
</html>