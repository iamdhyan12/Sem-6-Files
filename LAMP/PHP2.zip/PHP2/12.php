<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 12-1:  <br>";
$str = "Hello World!";
echo $str . "<br>";
echo trim($str,"Hed!");

echo "<br><br>Example 12-2:  <br>";
echo strstr("Hello world!","world");

echo "<br><br> Example 12-3:  <br>";
echo strstr("Hello world!",111);

echo "<br><br> Example 12-4:  <br>";
echo strstr("Hello world!","world",true);

echo "<br><br>Example 12-5:  <br>";
echo stristr("Hello world!","WORLD");

echo "<br><br> Example 12-6:  <br>";
echo stristr("Hello world!",111);

echo "<br><br> Example 12-7:  <br>";
echo stristr("Hello world!","WORLD",true);

?>

</body>
</html>