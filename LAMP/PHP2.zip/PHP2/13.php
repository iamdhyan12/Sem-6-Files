<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 13-1:  <br>";
echo ucfirst("hello world!");

echo "<br><br>Example 13-2:  <br>";
echo lcfirst("Hello world!");

echo "<br><br> Example 13-3:  <br>";
echo ucwords("hello world");

?>

</body>
</html>