<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 11-1:  <br>";
$str = "An example of a long word is: Supercalifragulistic";
echo wordwrap($str,15,"<br>\n");

echo "<br><br>Example 11-2:  <br>";
$str = "An example of a long word is: Supercalifragulistic";
echo wordwrap($str,15,"<br>\n",TRUE);

echo "<br><br> Example 11-3:  <br>";
$str = "An example of a long word is: Supercalifragulistic";
echo wordwrap($str,15);

?>

</body>
</html>