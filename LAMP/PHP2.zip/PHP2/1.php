<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 1-1:  <br>";
echo str_ireplace("WORLD","Peter","Hello world!");

echo "<br> <br> Example 1-2:  <br>";
$arr = array("blue","red","green","yellow");
print_r(str_ireplace("RED","pink",$arr,$i)); // Case-insensitive
echo "<br>" . "Replacements: $i";

echo "<br> <br>Example 1-3:  <br>";
$find = array("HELLO","WORLD"); // Case-insensitive
$replace = array("B");
$arr = array("Hello","world","!");
print_r(str_ireplace($find,$replace,$arr));

?>

</body>
</html>