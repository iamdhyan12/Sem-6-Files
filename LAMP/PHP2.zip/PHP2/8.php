<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 8-1:  <br>";
echo substr_compare("Hello world","Hello world",0);
echo "<p>If this function returns 0, the two strings are equal.</p>";

echo "Example 8-2:  <br>";
echo substr_compare("Hello world","world",6);

echo "<br><br> Example 8-3:  <br>";
echo substr_compare("world","or",1,2)."<br>";
echo substr_compare("world","ld",-2,2)."<br>";
echo substr_compare("world","orl",1,2)."<br>";
echo substr_compare("world","OR",1,2,TRUE)."<br>";
echo substr_compare("world","or",1,3)."<br>";
echo substr_compare("world","rl",1,2)."<br>";

echo "<br><br> Example 8-4:  <br>";
echo substr_compare("Hello world!","Hello world!",0)."<br>"; // the two strings are equal
echo substr_compare("Hello world!","Hello",0)."<br>"; // string1 is greater than string2
echo substr_compare("Hello world!","Hello world! Hello!",0)."<br>"; // string1 is less than string2



?>

</body>
</html>