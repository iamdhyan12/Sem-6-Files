<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 3-1:  <br>";
echo str_repeat("*",13);

echo "<br><br>Example 3-2:  <br>";
echo str_shuffle("Hello World");

?>

</body>
</html>