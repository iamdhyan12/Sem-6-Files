<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 2-1:  <br>";
$str = "Hello World";
echo str_pad($str,20,".");

echo "<br> <br> Example 2-2:  <br>";
$str = "Hello World";
echo str_pad($str,20,".",STR_PAD_LEFT);

echo "<br> <br>Example 2-3:  <br>";
$str = "Hello World";
echo str_pad($str,20,".:",STR_PAD_BOTH);

?>

</body>
</html>