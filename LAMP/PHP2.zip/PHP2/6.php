<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 6-1:  <br>";
echo strip_tags("Hello <b>world!</b>");

echo "<br><br> Example 6-2:  <br>";
echo strip_tags("Hello <b><i>world!</i></b>","<b>");

echo "<br><br> Example 6-3:  <br>";
echo stripos("I love php, I love php too!","PHP");

echo "<br><br> Example 6-4:  <br>";
echo stripos("I love php, I love php too!","PHP",8);

echo "<br><br> Example 6-5:  <br>";
echo strripos("I love php, I love php too!","PHP");

echo "<br><br> Example 6-6:  <br>";
echo strripos("I love php, I love php too!","PHP",-10);

echo "<br><br> Example 6-7:  <br>";
echo strrpos("I love php, I love php too!","php");

echo "<br><br> Example 6-8:  <br>";
echo strrpos("I love php, I love php too!","php",-10);

?>

</body>
</html>