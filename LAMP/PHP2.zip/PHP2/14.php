<!DOCTYPE html>
<html>
<body>

<?php
echo "Example 14-1:  <br>";
$arr = array('Hello','World!','Beautiful','Day!');
echo implode(" ",$arr);

echo "<br><br>Example 14-2:  <br>";
$arr = array('Hello','World!','Beautiful','Day!');
echo implode(" ",$arr)."<br>";
echo implode("+",$arr)."<br>";
echo implode("-",$arr)."<br>"; 
echo implode("X",$arr);

echo "<br><br> Example 14-3:  <br>";
$str = "Hello world. It's a beautiful day.";
print_r (explode(" ",$str));

echo "<br><br> Example 14-4:  <br>";
$str = 'one,two,three,four';

// zero limit
print_r(explode(',',$str,0));
print "<br>";

// positive limit
print_r(explode(',',$str,2));
print "<br>";

// negative limit 
print_r(explode(',',$str,-2));
?>

</body>
</html>